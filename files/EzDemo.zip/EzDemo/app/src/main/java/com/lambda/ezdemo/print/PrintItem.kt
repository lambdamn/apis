package com.lambda.ezdemo.print

open class PrintItem(val widthPercent: Int, val align: String, val type: String) {
}
