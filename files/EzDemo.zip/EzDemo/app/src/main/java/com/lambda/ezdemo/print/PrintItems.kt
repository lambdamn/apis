package com.lambda.ezdemo.print

import java.util.ArrayList

class PrintItems {
    var lines: ArrayList<List<PrintItem>> = ArrayList()

    fun addLine(vararg line: PrintItem){
        lines.add(line.toList())
    }

}
