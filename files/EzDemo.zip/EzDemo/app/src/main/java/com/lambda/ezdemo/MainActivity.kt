package com.lambda.ezdemo

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.os.RemoteException
import android.util.Base64
import android.util.Log
import android.view.View
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.golomt.payment.aidl.IPaymentListener
import com.golomt.payment.aidl.IPaymentService
import com.google.gson.Gson
import com.lambda.ezdemo.databinding.ActivityMainBinding
import com.lambda.ezdemo.print.PrintImage
import com.lambda.ezdemo.print.PrintItems
import com.lambda.ezdemo.print.PrintQrCode
import com.lambda.ezdemo.print.PrintSkip
import com.lambda.ezdemo.print.PrintText
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class MainActivity : AppCompatActivity() {
    private var mService: IPaymentService? = null
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.readSerialButton.setOnClickListener {
            if(mService != null){
                this.unbindService(mConnection)
            }
            binding.readSerialButton.visibility = View.INVISIBLE
            startReadCard()
        }

        binding.paymentButton.setOnClickListener {
            binding.paymentButton.visibility = View.INVISIBLE
            startCardPayment()
        }

        binding.settlementButton.setOnClickListener {
            binding.settlementButton.visibility = View.INVISIBLE
            startSettlement()
        }

        binding.printButton.setOnClickListener {
            printSample()
        }
    }

    private fun startSettlement(){
        // paymentType: 10 - Карт, 30 - Сошиал, 20 - Бэлэн мөнгө
        // ebarimtType: 1 - Хувь хүн, 2 - Байгууллага, 3 - Бизнес эрхлэгч хувь хүн, 4 - Ибаримт авахгүй
        val paymentType = 10 // paymentType 0 үед Payment апп дээр төлбөрийн хэрэгсэл сонгоно
        val ebarimtType = 4
        val skipPrint = true // Баримт хэвлэхгүй
        val amount = 1*100 // Үнийн дүнг 100р үржүүлнэ
        val uri =
            "golomt://payment/transaction?transType=Settle";
        val intent = Intent()
        intent.data = Uri.parse(uri)
        intent.action = "android.intent.action.GOLOMT.PAYMENT"
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        mStartSettlementForResult.launch(intent)
    }

    private var mStartSettlementForResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        Log.d("MA", "result: " + result.resultCode)
        binding.settlementButton.visibility = View.VISIBLE
        if (result.resultCode == Activity.RESULT_OK) {
            Log.d("MA", "result ok ")
            result.data?.extras?.let { bundle ->
                for (key in bundle.keySet()) {
                    Log.d("Bundle Debug", key + " = \"" + bundle.get(key) + "\"")
                }
                Log.d("EzDemo", bundle.toString())
            } ?: run {
                Log.d("EzDemo", "empty result")
            }
        } else {
            result.data?.extras?.let { bundle ->
                bundle.getString("message")?.let {
                    Log.d("EzDemo", "error message: $it")
                }
            } ?: run {
                Log.d("EzDemo", "Payment failed")
            }
        }
    }


    private fun printSample(){
        val printItems = PrintItems()
        val image = "golomt.png"
        try {
            val bitmap = this.assets
                .open(image)
                .use(BitmapFactory::decodeStream)
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
            val b = baos.toByteArray()
            val base64 = Base64.encodeToString(b, Base64.NO_WRAP or Base64.NO_PADDING or Base64.URL_SAFE)
//            LoggerUtils.d("baseee64: ${base64.length}")
            printItems.addLine(PrintImage(base64, 100, "CENTER"))

        } catch (e: IOException) {
            e.printStackTrace()
        }

        val textSize = 22f
        val labelWidth = 40
        val valueWidth = 60
        val labelAlign = "LEFT"
        val valueAlign = "RIGHT"
        val splitter = "--------------------------------------------------------------"
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

        printItems.addLine(PrintText("Нэр", textSize, false, labelWidth, labelAlign), PrintText("Merchant name", textSize, false, valueWidth, valueAlign))
        printItems.addLine(PrintText("Огноо", textSize, false, labelWidth, labelAlign), PrintText(sdf.format(
            Date()
        ), textSize, false, valueWidth, valueAlign))
        printItems.addLine(PrintText(splitter, textSize, false, 100, labelAlign))

        val productTextSize = 22f
        printItems.addLine(
            PrintText("Бараа", productTextSize, false, 25, labelAlign),
            PrintText("Тоо", productTextSize, false, 15, labelAlign),
            PrintText("Үнэ", productTextSize, false, 25, valueAlign),
            PrintText("Дүн", productTextSize, false, 35, valueAlign))
        printItems.addLine(PrintText(splitter, textSize, false, 100, labelAlign))

        printItems.addLine(
            PrintText("Бараа1", productTextSize, false, 25, labelAlign),
            PrintText("2ш", productTextSize, false, 15, labelAlign),
            PrintText("10,000.00", productTextSize, false, 25, valueAlign),
            PrintText("20,000.00", productTextSize, false, 35, valueAlign))

        printItems.addLine(PrintQrCode("Your QR Code here", 280f, 100, "CENTER"))
        printItems.addLine(PrintSkip(10f))

        val gson = Gson()
        val printData = gson.toJson(printItems);

        val intent = Intent()
        intent.data = Uri.parse("golomt://payment/transaction?transType=Print&printData=${printData}")
        intent.action = "android.intent.action.GOLOMT.PAYMENT"
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        mStartForPrintResult.launch(intent)
    }

    private var mStartForPrintResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        Log.d("MA", "result: " + result.resultCode)
        if (result.resultCode == Activity.RESULT_OK) {
            Log.d("MA", "result ok ")
        }
    }

    private fun startCardPayment(){
        // paymentType: 10 - Карт, 30 - Сошиал, 20 - Бэлэн мөнгө
        // ebarimtType: 1 - Хувь хүн, 2 - Байгууллага, 3 - Бизнес эрхлэгч хувь хүн, 4 - Ибаримт авахгүй
        val paymentType = 10 // paymentType 0 үед Payment апп дээр төлбөрийн хэрэгсэл сонгоно
        val ebarimtType = 4
        val skipPrint = true // Баримт хэвлэхгүй
        val amount = 1*100 // Үнийн дүнг 100р үржүүлнэ
        val uri =
            "golomt://payment/transaction?transType=Sale&amount=${amount}&paymentType=${paymentType}&ebarimtType=${ebarimtType}&skipPrint=${skipPrint}";
        val intent = Intent()
        intent.data = Uri.parse(uri)
        intent.action = "android.intent.action.GOLOMT.PAYMENT"
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        mStartForResult.launch(intent)
    }

    private var mStartForResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        Log.d("MA", "result: " + result.resultCode)
        if (result.resultCode == Activity.RESULT_OK) {
            Log.d("MA", "result ok ")
            result.data?.extras?.let { bundle ->
                val merchantName = bundle.getString("merchantName")
                val mid = bundle.getString("mid")
                val tid = bundle.getString("tid")
                val paymentType = bundle.getInt("paymentType")
                val amount = bundle.getLong("amount")
                val total = bundle.getLong("total")
                val discount = bundle.getLong("discount")
                val date = bundle.getString("date")
                val time = bundle.getString("time")
                val batchno = bundle.getString("batchNo")
                val traceno = bundle.getString("traceNo")
                val resultCode = bundle.getString("resultCode")
                val message = bundle.getString("message")
                val cardNo = bundle.getString("cardNo")
                val referenceNo = bundle.getString("referenceNo")
                val authCode = bundle.getString("authCode")

                // resultCode = "00" нөхцлийг шалгах
                this@MainActivity.binding.resultTv.text = "Payment result:  type -> $paymentType, resultCode -> $resultCode"

            } ?: run {
                Log.d("EzDemo", "empty result")
            }
        } else {
            result.data?.extras?.let { bundle ->
                bundle.getString("message")?.let {
                    Log.d("EzDemo", "error message: $it")
                }
            } ?: run {
                Log.d("EzDemo", "Payment failed")
            }
        }
    }

    private val mPaymentListener =  object : IPaymentListener.Stub ( )  {
        override fun onSuccess(data: Bundle?) {
            Log.d("", "on success")
            val cardNo = data?.getString("card")
            this@MainActivity.runOnUiThread {
                this@MainActivity.binding.readSerialButton.visibility = View.VISIBLE
                "$cardNo".also { this@MainActivity.binding.resultTv.text = "Card No: $it" }
            }
        }

        override fun onFail(failCode: String?, msg: String?) {
            Log.d("", "card listener fail: [$failCode] $msg")
            this@MainActivity.runOnUiThread {
                this@MainActivity.binding.readSerialButton.visibility = View.VISIBLE
            }
        }
    }

    private val mConnection = object : ServiceConnection {

        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            // This is called when the connection with the service has been
            // established, giving us the service object we can use to
            // interact with the service.  We are communicating with our
            // service through an IDL interface, so get a client-side
            // representation of that from the raw service object.
            mService = IPaymentService.Stub.asInterface(service)

            // We want to monitor the service for as long as we are
            // connected to it.
            Log.d("", "On service connedted...")
            try {
                mService?.readCardSerial(30, mPaymentListener)
            } catch (e: RemoteException) {
                e.printStackTrace()
                // In this case the service has crashed before we could even
                // do anything with it; we can count on soon being
                // disconnected (and then reconnected if it can be restarted)
                // so there is no need to do anything here.
            }

            // As part of the sample, tell the user what happened.
//            ToastUtils.showLongToast(this@LoginFragmentx, "Connected")
        }

        override fun onServiceDisconnected(className: ComponentName) {
            Log.d("", "on service disconnected")
            // This is called when the connection with the service has been
            // unexpectedly disconnected -- that is, its process crashed.
            mService = null
        }

        override fun onBindingDied(name: ComponentName?) {
            super.onBindingDied(name)
            Log.d("", "on binding died, $name")
        }

        override fun onNullBinding(name: ComponentName?) {
            super.onNullBinding(name)
            Log.d("", "on null binding, $name")
        }
    }

    private fun startReadCard(){
        val intent = Intent()
        intent.action = "android.intent.action.GOLOMT.PAYMENT.SERVICE"
        intent.setPackage("com.lambda.ezpay")
        this.bindService(intent, mConnection, Context.BIND_AUTO_CREATE)
    }

}
