package com.lambda.ezdemo.print

import com.lambda.ezdemo.print.PrintItem

class PrintQrCode(val qrCode: String, var height: Float, widthPercent: Int, align: String) : PrintItem(widthPercent, align, "QrCode") {
}
