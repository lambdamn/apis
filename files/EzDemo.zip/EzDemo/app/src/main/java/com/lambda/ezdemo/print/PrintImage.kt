package com.lambda.ezdemo.print

class PrintImage(val base64: String, widthPercent: Int, align: String) : PrintItem(widthPercent, align, "Image") {
}
