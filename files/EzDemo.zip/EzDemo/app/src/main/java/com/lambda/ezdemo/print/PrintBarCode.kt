package com.lambda.ezdemo.print

class PrintBarCode(val barcode: String, var width: Float, var height: Float, widthPercent: Int, align: String) : PrintItem(widthPercent, align, "BarCode") {
}
