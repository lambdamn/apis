package com.lambda.ezdemo.print

class PrintText(val text: String, var textSize: Float, val bold: Boolean, widthPercent: Int, align: String) : PrintItem(widthPercent, align, "Text") {
}
