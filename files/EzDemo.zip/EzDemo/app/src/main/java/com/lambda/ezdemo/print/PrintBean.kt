package com.lambda.ezdemo.print

class PrintBean {
    var lines: List<List<PrintItem>>? = null
}
