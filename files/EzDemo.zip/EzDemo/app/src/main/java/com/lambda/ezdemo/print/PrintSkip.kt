package com.lambda.ezdemo.print

import com.lambda.ezdemo.print.PrintItem

class PrintSkip(var height: Float) : PrintItem(0, "LEFT", "Skip") {
}
